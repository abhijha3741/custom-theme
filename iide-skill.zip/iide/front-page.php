<?php

/**
 * Template Name: Front Page Template
 *
 * Description: A page template that provides a key component of WordPress as a CMS
 * by meeting the need for a carefully crafted introductory page. The front page template
 * in Twenty Twelve consists of a page content area for adding text, images, video --
 * anything you'd like -- followed by front-page-only widgets in one or two columns.
 *
 * @package WordPress
 */

get_header(); ?>
<section class="hero_banner">
    <div id="carouselExampleCrossfade" class="relative" data-te-carousel-init data-te-ride="carousel">
        <!--Carousel indicators-->
        <div class="absolute inset-x-0 bottom-0 z-[2] mx-[15%] mb-4 flex list-none justify-center p-0" data-te-carousel-indicators>
            <button type="button" data-te-target="#carouselExampleCrossfade" data-te-slide-to="0" data-te-carousel-active class="mx-[3px] box-content h-[3px] w-[30px] flex-initial cursor-pointer border-0 border-y-[10px] border-solid border-transparent bg-white bg-clip-padding p-0 -indent-[999px] opacity-50 transition-opacity duration-[600ms] ease-[cubic-bezier(0.25,0.1,0.25,1.0)] motion-reduce:transition-none" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-te-target="#carouselExampleCrossfade" data-te-slide-to="1" class="mx-[3px] box-content h-[3px] w-[30px] flex-initial cursor-pointer border-0 border-y-[10px] border-solid border-transparent bg-white bg-clip-padding p-0 -indent-[999px] opacity-50 transition-opacity duration-[600ms] ease-[cubic-bezier(0.25,0.1,0.25,1.0)] motion-reduce:transition-none" aria-label="Slide 2"></button>
            <button type="button" data-te-target="#carouselExampleCrossfade" data-te-slide-to="2" class="mx-[3px] box-content h-[3px] w-[30px] flex-initial cursor-pointer border-0 border-y-[10px] border-solid border-transparent bg-white bg-clip-padding p-0 -indent-[999px] opacity-50 transition-opacity duration-[600ms] ease-[cubic-bezier(0.25,0.1,0.25,1.0)] motion-reduce:transition-none" aria-label="Slide 3"></button>
        </div>

        <!--Carousel items-->
        <div class="relative w-full overflow-hidden after:clear-both after:block after:content-['']">
            <!--First item-->
            <div class="relative float-left -mr-[100%] w-full !transform-none opacity-0 transition-opacity duration-[600ms] ease-in-out motion-reduce:transition-none" data-te-carousel-fade data-te-carousel-item data-te-carousel-active>
                <?php
                // Replace 'your_attachment_id' with the actual attachment ID of your media file.
                $attachment_id = 1266;
                $attachment_url = wp_get_attachment_url($attachment_id);
                $attachment_title = get_the_title($attachment_id); // Get the image title.
                ?>
                <img src="<?php echo esc_url($attachment_url); ?>" class="block w-full" alt="<?php echo esc_attr($attachment_title); ?>" />
                <div class="absolute inset-x-[5%] top-[10%] block py-5 text-start text-black md:block">
                    <?php
                    // Replace 'your_attachment_id' with the actual attachment ID of your media file.
                    $attachment_id = 1267;
                    $attachment_url = wp_get_attachment_url($attachment_id);
                    $attachment_title = get_the_title($attachment_id); // Get the image title.
                    ?>

                    <div class="et_pb_slider_container_inner w3_bg">
                        <img src="<?php echo esc_url($attachment_url); ?>" class="block w-48 mb-4" alt="<?php echo esc_attr($attachment_title); ?>">
                        <div class="et_pb_slide_description w3_bg">
                            <h1 class="et_pb_slide_title"><a href="https://iide.co/online-digital-marketing-course/">
                                    <p class="banner-tag mb-2"><span class="bg-[#9af0c1] px-5 py-1.5 text-sm font-medium font-iide_normal rounded-2xl">Recently Updated</span></p>
                                </a>
                                <p class="text-3xl mb-4 font-semibold"><a href="https://iide.co/online-digital-marketing-course/"><span class="text-2xl font-semibold text-[#0c71c3] mb-2">[Advanced + Professional]</span><br>Online Digital Marketing Courses with Certifications</a></p>
                            </h1>
                            <div class="mb-5">
                                <p class="text-base w-[60%]">Learn advanced &amp; strategic concepts of digital marketing with 100% job assistance, 20+ Digital Marketing &amp; AI tools and case studies &amp; simulation.</p>
                                <p class="text-lg mt-4"><strong>Program Commences: Sep 13, 2023</strong></p>
                            </div>
                            <button type="button" data-te-ripple-init data-te-ripple-color="light" class="inline-block rounded bg-[#0c71c3] px-16 font-semibold pb-1.5 pt-1.5 text-xl leading-normal text-white">
                                View Course
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <!--Second item-->
            <div class="relative float-left -mr-[100%] hidden w-full !transform-none opacity-0 transition-opacity duration-[600ms] ease-in-out motion-reduce:transition-none" data-te-carousel-fade data-te-carousel-item>
                <?php
                // Replace 'your_attachment_id' with the actual attachment ID of your media file.
                $attachment_id = 1265;
                $attachment_url = wp_get_attachment_url($attachment_id);
                $attachment_title = get_the_title($attachment_id); // Get the image title.
                ?>
                <img src="<?php echo esc_url($attachment_url); ?>" class="block w-full" alt="<?php echo esc_attr($attachment_title); ?>" />
                <div class="absolute inset-x-[5%] top-[10%] block py-5 text-start text-black md:block">
                    <?php
                    // Replace 'your_attachment_id' with the actual attachment ID of your media file.
                    $attachment_id = 1267;
                    $attachment_url = wp_get_attachment_url($attachment_id);
                    $attachment_title = get_the_title($attachment_id); // Get the image title.
                    ?>

                    <div class="et_pb_slider_container_inner w3_bg">
                        <img src="<?php echo esc_url($attachment_url); ?>" class="block w-48 mb-4" alt="<?php echo esc_attr($attachment_title); ?>">
                        <div class="et_pb_slide_description w3_bg">
                            <h2 class="et_pb_slide_title"><a href="https://iide.co/online-digital-marketing-course/">
                                    <p class="banner-tag mb-2 hidden"><span class="bg-[#9af0c1] px-5 py-1.5 text-sm font-medium font-iide_normal rounded-2xl">Recently Updated</span></p>
                                </a>
                                <p class="text-3xl mb-4 font-semibold"><a href="https://iide.co/online-digital-marketing-course/"><span class="text-2xl font-semibold text-[#0c71c3] mb-2">[Advanced + Professional]</span><br>Online Digital Marketing Courses with Certifications</a></p>
                            </h2>
                            <div class="mb-5">
                                <p class="text-base w-[60%]">Learn advanced &amp; strategic concepts of digital marketing with 100% job assistance, 20+ Digital Marketing &amp; AI tools and case studies &amp; simulation.</p>
                                <p class="text-lg mt-4"><strong>Program Commences: Sep 13, 2023</strong></p>
                            </div>
                            <button type="button" data-te-ripple-init data-te-ripple-color="light" class="inline-block rounded bg-[#0c71c3] px-16 font-semibold pb-1.5 pt-1.5 text-xl leading-normal text-white">
                                View Course
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <!--Third item-->
            <div class="relative float-left -mr-[100%] hidden w-full !transform-none opacity-0 transition-opacity duration-[600ms] ease-in-out motion-reduce:transition-none" data-te-carousel-fade data-te-carousel-item>
                <?php
                // Replace 'your_attachment_id' with the actual attachment ID of your media file.
                $attachment_id = 1264;
                $attachment_url = wp_get_attachment_url($attachment_id);
                $attachment_title = get_the_title($attachment_id); // Get the image title.
                ?>
                <img src="<?php echo esc_url($attachment_url); ?>" class="block w-full" alt="<?php echo esc_attr($attachment_title); ?>" />
                <div class="absolute inset-x-[5%] top-[10%] block py-5 text-start text-white md:block">
                    <?php
                    // Replace 'your_attachment_id' with the actual attachment ID of your media file.
                    $attachment_id = 1269;
                    $attachment_url = wp_get_attachment_url($attachment_id);
                    $attachment_title = get_the_title($attachment_id); // Get the image title.
                    ?>

                    <div class="et_pb_slider_container_inner w3_bg">
                        <img src="<?php echo esc_url($attachment_url); ?>" class="block w-48 mb-4" alt="<?php echo esc_attr($attachment_title); ?>">
                        <div class="et_pb_slide_description w3_bg">
                            <h2 class="et_pb_slide_title"><a href="https://iide.co/online-digital-marketing-course/">
                                    <p class="banner-tag mb-2 hidden"><span class="bg-[#9af0c1] px-5 py-1.5 text-sm font-medium font-iide_normal rounded-2xl">Recently Updated</span></p>
                                </a>
                                <p class="text-3xl mb-4 font-semibold"><a href="https://iide.co/online-digital-marketing-course/"><span class="text-2xl font-semibold text-[#0c71c3] mb-2">[Advanced + Professional]</span><br>Online Digital Marketing Courses with Certifications</a></p>
                            </h2>
                            <div class="mb-5">
                                <p class="text-base w-[60%]">Learn advanced &amp; strategic concepts of digital marketing with 100% job assistance, 20+ Digital Marketing &amp; AI tools and case studies &amp; simulation.</p>
                                <p class="text-lg mt-4"><strong>Program Commences: Sep 13, 2023</strong></p>
                            </div>
                            <button type="button" data-te-ripple-init data-te-ripple-color="light" class="inline-block rounded bg-[#0c71c3] px-16 font-semibold pb-1.5 pt-1.5 text-xl leading-normal text-white">
                                View Course
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--Carousel controls - prev item-->
        <button class="absolute bottom-0 left-0 top-0 z-[1] flex w-[5%] items-center justify-center border-0 bg-none p-0 text-center text-white font-black opacity-50 transition-opacity duration-150 ease-[cubic-bezier(0.25,0.1,0.25,1.0)] hover:text-white hover:no-underline hover:opacity-90 hover:outline-none focus:text-white focus:no-underline focus:opacity-90 focus:outline-none motion-reduce:transition-none" type="button" data-te-target="#carouselExampleCrossfade" data-te-slide="prev">
            <span class="inline-block h-8 w-8">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-6 w-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
                </svg>
            </span>
            <span class="!absolute !-m-px !h-px !w-px !overflow-hidden !whitespace-nowrap !border-0 !p-0 ![clip:rect(0,0,0,0)]">Previous</span>
        </button>
        <!--Carousel controls - next item-->
        <button class="absolute bottom-0 right-0 top-0 z-[1] flex w-[5%] items-center justify-center border-0 bg-none p-0 text-center text-white font-black opacity-50 transition-opacity duration-150 ease-[cubic-bezier(0.25,0.1,0.25,1.0)] hover:text-white hover:no-underline hover:opacity-90 hover:outline-none focus:text-white focus:no-underline focus:opacity-90 focus:outline-none motion-reduce:transition-none" type="button" data-te-target="#carouselExampleCrossfade" data-te-slide="next">
            <span class="inline-block h-8 w-8">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-6 w-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
                </svg>
            </span>
            <span class="!absolute !-m-px !h-px !w-px !overflow-hidden !whitespace-nowrap !border-0 !p-0 ![clip:rect(0,0,0,0)]">Next</span>
        </button>
    </div>
</section>
<section class="alumni-section">
    <div class="alumni-container py-10 max-w-7xl m-auto">
        <h3 class="text-xl font-semibold text-center">IIDE Alumni Work At</h3>
        <div class="image-gallery">
            <section class="logoMarqueeSection">
                <div class="container" id="logoMarqueeSection">
                    <div class="default-content-container flex items-center">
                        <div class="default-content-container-inner marquee-wrapper relative overflow-hidden inline-block">
                            <div class="marquee" style="animation-duration: 57s;">
                                <a target="_blank"><img src="/pdf-test/wp-content/uploads/2023/09/Social-panga-and-leo-burnett-logo.png" title="" class="marqueelogo" style="width: auto; max-width: none;"></a>
                                <a target="_blank"><img src="http://localhost/pdf-test/wp-content/uploads/2023/09/Wavemaker-and-Group-M-logo.png" title="" class="marqueelogo" style="width: auto; max-width: none;"></a>
                                <a target="_blank"><img src="http://localhost/pdf-test/wp-content/uploads/2023/09/Digital-education-institute-top-companies-times-of-india-oneplus.png" title="" class="marqueelogo" style="width: auto; max-width: none;"></a>
                                <a target="_blank"><img src="http://localhost/pdf-test/wp-content/uploads/2023/09/Madison-World-and-Sugar-Logo.png" title="" class="marqueelogo" style="width: auto; max-width: none;"></a>
                                <a target="_blank"><img src="http://localhost/pdf-test/wp-content/uploads/2023/09/Digital-education-institute-top-companies-mediadotnet-foxymoran-1.png" title="" class="marqueelogo" style="width: auto; max-width: none;"></a>
                                <a target="_blank"><img src="http://localhost/pdf-test/wp-content/uploads/2023/09/Digital-education-institute-top-companies-performics-socheers.png" title="" class="marqueelogo" style="width: auto; max-width: none;"></a>
                                <a target="_blank"><img src="http://localhost/pdf-test/wp-content/uploads/2023/09/Digital-education-institute-top-companies-kinnect-schbang.png" title="" class="marqueelogo" style="width: auto; max-width: none;"></a>
                            </div>
                            <div class="marquee" style="animation-duration: 57s;">
                                <a target="_blank"><img src="/pdf-test/wp-content/uploads/2023/09/Social-panga-and-leo-burnett-logo.png" title="" class="marqueelogo" style="width: auto; max-width: none;"></a>
                                <a target="_blank"><img src="http://localhost/pdf-test/wp-content/uploads/2023/09/Wavemaker-and-Group-M-logo.png" title="" class="marqueelogo" style="width: auto; max-width: none;"></a>
                                <a target="_blank"><img src="http://localhost/pdf-test/wp-content/uploads/2023/09/Digital-education-institute-top-companies-times-of-india-oneplus.png" title="" class="marqueelogo" style="width: auto; max-width: none;"></a>
                                <a target="_blank"><img src="http://localhost/pdf-test/wp-content/uploads/2023/09/Madison-World-and-Sugar-Logo.png" title="" class="marqueelogo" style="width: auto; max-width: none;"></a>
                                <a target="_blank"><img src="http://localhost/pdf-test/wp-content/uploads/2023/09/Digital-education-institute-top-companies-mediadotnet-foxymoran-1.png" title="" class="marqueelogo" style="width: auto; max-width: none;"></a>
                                <a target="_blank"><img src="http://localhost/pdf-test/wp-content/uploads/2023/09/Digital-education-institute-top-companies-performics-socheers.png" title="" class="marqueelogo" style="width: auto; max-width: none;"></a>
                                <a target="_blank"><img src="http://localhost/pdf-test/wp-content/uploads/2023/09/Digital-education-institute-top-companies-kinnect-schbang.png" title="" class="marqueelogo" style="width: auto; max-width: none;"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</section>

<section class="programs-section bg-[#faf9f8]">
    <div class="alumni-container py-10 max-w-7xl m-auto">
        <div class="main-heading">
            <h2 class="relative text-3xl mb-8 font-semibold before:block before:absolute before:h-1 before:w-[80px] before:bottom-[-25px] before:bg-[#0c71c3]">Our Programmes</h2>
            <div class="grid grid-cols-3 gap-x-8 max-w-[1100px] m-auto py-10">
                <?php
                // Define a custom query to fetch posts.
                $args = array(
                    'post_type' => 'post', // Specify the post type as 'post'.
                    'posts_per_page' => 3, // Retrieve all posts. You can adjust this number as needed.
                );

                $custom_query = new WP_Query($args);

                // Check if there are posts to display.
                if ($custom_query->have_posts()) {
                    // Loop through each post.
                    while ($custom_query->have_posts()) {
                        $custom_query->the_post();
                        // Get the post title.
                        $post_title = get_the_title();
                        // Get the post content.
                        $post_content = get_the_content();
                        // Get the featured image URL.
                        $featured_image_url = get_the_post_thumbnail_url();
                        // Retrieve the custom field value for the current post.
                        $custom_field_value = get_post_meta(get_the_ID(), 'blue_chip', true);
                ?>
                        <div class="relative h-[450px] bg-white shadow-[0_2px_15px_-3px_rgba(0,0,0,0.07),0_10px_20px_-2px_rgba(0,0,0,0.04)] dark:bg-neutral-700">
                            <img class="w-[100%] object-cover h-[100%]" src="<?php echo esc_url($featured_image_url); ?>" alt="" />
                            <div class="absolute bottom-0 p-6">
                                <span class="text-white bg-iide text-xs rounded-md px-2 py-1 uppercase font-semibold mb-2 inline-block"><?php echo esc_html($custom_field_value); ?></span>
                                <h5 class="mb-2 text-xl font-medium leading-tight text-white">
                                    <?php echo esc_html($post_title); ?>
                                </h5>
                                <p class="mb-4 text-base text-white">
                                    <?php echo wp_kses_post($post_content); ?>
                                </p>
                            </div>
                        </div>
                <?php
                    }
                    // Restore the global post data.
                    wp_reset_postdata();
                } else {
                    // If no posts are found.
                    echo 'No posts found.';
                }
                ?>
            </div>


        </div>
    </div>
</section>

<section class="Register-section bg-gradient-to-r from-[#0072bd] to-[#23a6de] font-iide_normal">
    <div class="w-[75%] m-auto py-10 flex justify-between items-center ">
        <p class="text-white text-[26px] font-medium ">Start with a Free Live MasterClass</p>
        <a href="#" data-te-ripple-init data-te-ripple-color="light" class="inline-block rounded bg-white px-5 font-semibold py-4 text-[22px] leading-none text-[#0c71c3]">
            Register Now
        </a>
    </div>
</section>

<?php get_footer(); ?>