/** @type {import('tailwindcss').Config} */
module.exports = {
	content: ["./*.{php,html,js}"],
	theme: {
		extend: {
			fontFamily: {
				iide_normal: "'iide-normal',sans-serif",
				iide_medium: "'iide-medium',sans-serif",
				iide_bold: "'iide-bold',sans-serif",
			},
			colors: {
				iide: "#27aae1",
			},
		},
	},
	plugins: [],
};
